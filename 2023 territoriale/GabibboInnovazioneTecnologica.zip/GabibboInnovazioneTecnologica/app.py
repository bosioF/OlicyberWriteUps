from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import os
import bcrypt

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Set up database connection
conn = sqlite3.connect('notes.db', check_same_thread=False)
c = conn.cursor()

# Create tables if they don't exist
c.execute('''CREATE TABLE IF NOT EXISTS users
			 (id INTEGER PRIMARY KEY AUTOINCREMENT,
			  username TEXT NOT NULL,
			  password TEXT NOT NULL);''')

c.execute('''CREATE TABLE IF NOT EXISTS notes
			 (id INTEGER PRIMARY KEY AUTOINCREMENT,
			  user_id INTEGER NOT NULL,
			  note TEXT NOT NULL,
			  FOREIGN KEY(user_id) REFERENCES users(id));''')

# Create an initial admin user if it doesn't exist
c.execute("SELECT * FROM users WHERE username = 'admin'")
if not c.fetchone():
	hashed_pw = '$2b$12$AQ6terssqMr7pUBQleGDaut1hzaZ2xVotg3J/wkighj3..5DPH8Ji'
	c.execute("INSERT INTO users (username, password) VALUES (?, ?)", ('admin', hashed_pw))
	conn.commit()

# create two initial notes for the admin user if don't exist
c.execute("SELECT * FROM notes WHERE user_id = 1")
if not c.fetchone():
	c.execute("INSERT INTO notes (user_id, note) VALUES (?, ?)", (1, 'My first note!'))
	c.execute("INSERT INTO notes (user_id, note) VALUES (?, ?)", (1, os.environ.get("FLAG", "My example flag!")))
	conn.commit()

@app.route('/', methods=['GET', 'POST'])
def notes():
	if 'username' not in session:
		return redirect(url_for('login'))

	if request.method == 'POST':
		# TODO: Implement note creation functionality
		flash('TODO: Implement note creation functionality')

	c.execute("SELECT * FROM notes WHERE user_id = ?", (session['user_id'],))
	notes = c.fetchall()
	return render_template('notes.html', notes=notes)

@app.route('/login', methods=['GET', 'POST'])
def login():
	if 'username' in session:
		return redirect(url_for('notes'))

	if request.method == 'POST':
		username = request.form['username']
		password = request.form['password']
		c.execute("SELECT * FROM users WHERE username = ?", (username,))
		user = c.fetchone()
		if user and bcrypt.checkpw(password.encode('utf-8'), user[2].encode('utf-8')):
			session['username'] = user[1]
			session['user_id'] = user[0]
			return redirect(url_for('notes'))
		else:
			flash('Invalid login credentials')
			return redirect(url_for('login'))

	return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
	if request.method == 'POST':
		# TODO: Implement registration functionality
		pass

	return "TODO: Implement registration functionality"

@app.route('/logout')
def logout():
	session.pop('username', None)
	session.pop('user_id', None)
	return redirect(url_for('login'))

if __name__ == '__main__':
	app.run(debug=True)